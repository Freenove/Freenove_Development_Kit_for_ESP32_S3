
Simple Slider
"""""""""""""""""""""""""

.. lv_example:: widgets/slider/lv_example_slider_1
  :language: c

Slider with custom style
"""""""""""""""""""""""""

.. lv_example:: widgets/slider/lv_example_slider_2
  :language: c
  
Slider with extended drawer
""""""""""""""""""""""""""""

.. lv_example:: widgets/slider/lv_example_slider_3
  :language: c
  

