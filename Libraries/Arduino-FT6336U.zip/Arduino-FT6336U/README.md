# FT6336U Library
FocalTech FT6336U (Self-Capacitive Touch Panel Controller) library for Arduino.

## License
This code is released under the MIT License. Please see [LICENSE](https://github.com/aselectroworks/Arduino-FT6336U/blob/master/LICENSE) for the full text.